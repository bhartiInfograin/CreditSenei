const express = require('express')
const bodyParser = require('body-parser')
const axios = require('axios');
const app = express();
const querystring = require('querystring');
var cors = require('cors');
const cookieParser = require("cookie-parser")



//Static files
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json());
app.use(cors());
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

var jsonId;
var trackingToken;
var awsId;

app.post("/login", (req, res) => {

    const j_username = req.body.j_username;
    const j_password = req.body.j_password;

    if (j_username == "" || j_username == undefined || j_username == null) {
        return res.json({ statusCode: 401, statusMsg: "username required" })
    }

    if (j_password == "" || j_password == undefined || j_password == null) {
        return res.json({ statusCode: 402, statusMsg: "password required" })
    }

    const article = {
        "j_username": j_username,
        "j_password": j_password,
        "loginType": "PARTNER_API"
    }

    let response = null;
    new Promise(async (resolve, reject) => {
        try {
            response = await axios({
                method: 'post',
                url: 'https://stage-sc.consumerdirect.com/external-login',
                headers: {
                    'Authorization': 'Basic Y3JlZGl0c2Vuc2VpOnRlbWlkZW50aW91cw==',
                    'content-type': 'application/x-www-form-urlencoded'
                },
                data: querystring.stringify(article)
            });
        } catch (ex) {
            response = null;
            return res.json({ statusMsg: ex.message })
        }
 if(response){

          const json = response.data;
            const header = response.headers
            const cookiedata = header["set-cookie"]
            const cookiedata_jsonId = cookiedata[0];
            const cookiedata_trackingToken = cookiedata[2];
            const cookiedata_awsId = cookiedata[5];

            jsonId = cookiedata_jsonId.split(";")[0].split("=")[1]
            trackingToken = cookiedata_trackingToken.split(";")[0].split("=")[1]
            awsId = cookiedata_awsId.split(";")[0].split("=")[1]

            console.log("response", response.data.success);
            console.log("jsonId trackingTokenawsId", jsonId, trackingToken, awsId);
  
    res.cookie("JSESSIONID", jsonId);
    res.cookie("AWSELB",awsId);
    res.cookie("TRACKING",trackingToken);
    return res.json(json)
 }
       

        // if (response) {

          
        //     const header = response.headers
        //     const cookiedata = header["set-cookie"]
        //     const cookiedata_jsonId = cookiedata[0];
        //     const cookiedata_trackingToken = cookiedata[2];
        //     const cookiedata_awsId = cookiedata[5];

        //     jsonId = cookiedata_jsonId.split(";")[0].split("=")[1]
        //     trackingToken = cookiedata_trackingToken.split(";")[0].split("=")[1]
        //     awsId = cookiedata_awsId.split(";")[0].split("=")[1]

        //     console.log("response", response.data.success);
        //     console.log("jsonId trackingTokenawsId", jsonId, trackingToken, awsId);

        //     if (response.data.success == true) {
                
        //          try{
                 
        //             const result = await axios({
        //                             method: 'GET',
        //                             url: 'https://stage-sc.consumerdirect.com/member/credit-report/3b/simple.htm?format=json',
        //                             headers: {
        //                                 'Authorization': 'Basic Y3JlZGl0c2Vuc2VpOnRlbWlkZW50aW91cw==',
        //                                 "accept": "application/json",
        //                                 "Accept":"*/*",
        //                                 "Accept-Encoding":"gzip, deflate, br",
        //                                 "Connection":"keep-alive",
        //                                 "TRACKING":trackingToken,
        //                                 "AWSELB":awsId,
        //                                 "JSESSIONID":jsonId,
        //                             },
        //                         })
        //                         if (result) {
        //                             console.log("NADMEME");
        //                             console.log("result", result)
        //                             const data = result;
        //                             return res.send(data.toString())
        //                         }

        //         }catch (error) {
        //             console.log("creditreporterror", error.toString())
        //             return res.json({ statusMsg: error.toString() })

        //         }


        //     }

           
        // }
      
    });

})



app.get("/credit_report", (req, res) => {
console.log("creditreport api calling");
    let response = null;
    new Promise(async (resolve, reject) => {
        try {
            response = await axios({
                method: 'GET',
                url: 'https://stage-sc.consumerdirect.com/member/credit-report/3b/simple.htm?format=json',
                headers: {
                    'Authorization': 'Basic Y3JlZGl0c2Vuc2VpOnRlbWlkZW50aW91cw==',
                    "TRACKING":"e2e1084b-4df6-472e-bc3f-64ce14a247f8",
                    "AWSELB":"B9130D2D148E7E2A3BACAE4393BDC54AC658302830D616D6A01C1D47F9FF22720FBCA4C1645E7EF181A21985CC07AA58B05BD40795D2CAFFA9D560ADC738C472374281DEDDECD3278C169346A5C26D4448B9330A47",
                    "JSESSIONID":"5F452F503677CCFBB1EC76EA95E31F8C",
                    "accept": "application/json"
                },
            }
            );
        } catch (ex) {
            response = null;
            console.log("ex",ex.toString())
            return res.json({ statusMsg: ex })

        }
        if (response) {
            const json = response.data;
            console.log("json", json)
            return res.send(json)
        }
    });

})


app.listen(2000, (error) => {
    if (error) {
        console.log("error", error)
    } else {
        console.log("server in running on 2000");
    }
})





 // headers: {
                        //     'Authorization': 'Basic Y3JlZGl0c2Vuc2VpOnRlbWlkZW50aW91cw==',
                            // "Cookies": (
                            //     TRACKING = trackingToken,
                            //     AWSELB = awsId,
                            //     JSESSIONID = jsonId
                            // ),
                            // "Cookie":trackingToken ,
                            // "Cookie":awsId,
                            // "Cookie":jsonId 
                            // "Cookies":("TRACKING",trackingToken,"AWSELB",awsId,"JSESSIONID",jsonId),

                            // "Cookie": TRACKING = trackingToken,
                            // "Cookie": AWSELB = awsId,
                            // "Cookie": JSESSIONID = jsonId,
                            
                        //     "accept": "application/json"
                        // },
                        // Cookie: (
                        //     TRACKING = trackingToken,
                        //     AWSELB = awsId,
                        //     JSESSIONID = jsonId
                    
                        // )

                        // headers: {
                        //     'Authorization': 'Basic Y3JlZGl0c2Vuc2VpOnRlbWlkZW50aW91cw==',
                        //     "set-cookie": TRACKING = trackingToken,
                        //     "set-cookie":  AWSELB = awsId,
                        //     "set-cookie":   JSESSIONID = jsonId,
                        //    "accept": "application/json"
                        // },


                          // console.log("jsonId", jsonId)
                  //  console.log("trackingToken", trackingToken)
                  //  console.log("awsId", awsId)